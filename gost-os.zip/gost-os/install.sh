#!/usr/bin/env bash
# ============================================================================
# GOST / PERIMETR  —  installer
# Run on a FRESH Raspberry Pi OS Lite (64-bit) on a Raspberry Pi 5.
#   sudo ./install.sh
# Turns the card into a kiosk appliance that boots straight into the head unit.
# ============================================================================
set -euo pipefail

if [[ $EUID -ne 0 ]]; then echo "Run with sudo."; exit 1; fi

TARGET=/opt/gost
SRC="$(cd "$(dirname "$0")" && pwd)"
GOST_USER="${SUDO_USER:-}"
# no SUDO_USER (e.g. run by the firstboot service): use the uid-1000 user, or create one
[[ -z "$GOST_USER" ]] && GOST_USER="$(getent passwd 1000 | cut -d: -f1 || true)"
[[ -z "$GOST_USER" ]] && { useradd -m -s /bin/bash gost; GOST_USER=gost; }

echo "==> Installing GOST/PERIMETR for user: $GOST_USER"

echo "==> Packages"
apt-get update
apt-get install -y --no-install-recommends \
  chromium-browser cage seatd mpv \
  python3 python3-venv python3-pip \
  swig python3-dev build-essential liblgpio-dev \
  fonts-dejavu-core

# some images ship chromium as 'chromium'
command -v chromium-browser >/dev/null 2>&1 || apt-get install -y chromium || true

echo "==> Enabling SPI (for MCP3008 pots)"
CFG=/boot/firmware/config.txt
[[ -f $CFG ]] || CFG=/boot/config.txt
grep -q "^dtparam=spi=on" "$CFG" || echo "dtparam=spi=on" >> "$CFG"

echo "==> Copying app to $TARGET"
mkdir -p "$TARGET"
cp -r "$SRC/app" "$SRC/backend" "$SRC/system" "$SRC/tools" "$SRC/media" "$SRC/maps" "$TARGET/" 2>/dev/null || cp -r "$SRC/app" "$SRC/backend" "$SRC/system" "$SRC/tools" "$TARGET/"
mkdir -p "$TARGET/media/TV" "$TARGET/media/Dashcam" "$TARGET/maps"
chmod +x "$TARGET/system/kiosk-start.sh"

echo "==> Python venv + deps"
python3 -m venv "$TARGET/venv"
"$TARGET/venv/bin/pip" install --upgrade pip
"$TARGET/venv/bin/pip" install -r "$TARGET/backend/requirements.txt"

echo "==> Permissions"
# input group for GPIO, dialout for the OBD USB serial adapter
usermod -aG gpio,spi,dialout,video,input,seat "$GOST_USER" || true
chown -R "$GOST_USER":"$GOST_USER" "$TARGET"

echo "==> systemd services"
# stamp the real user into the units
sed "s/^User=gost/User=$GOST_USER/" "$TARGET/system/hud-backend.service" > /etc/systemd/system/hud-backend.service
sed "s/^User=gost/User=$GOST_USER/" "$TARGET/system/hud-kiosk.service"   > /etc/systemd/system/hud-kiosk.service
systemctl daemon-reload
systemctl enable seatd
systemctl enable hud-backend.service
systemctl enable hud-kiosk.service

echo
echo "============================================================"
echo " Done. Reboot to launch the head unit:   sudo reboot"
echo " Drop .mp4 videos into: $TARGET/media/Videos  (or a USB stick)"
echo " Wiring reference:      $TARGET/docs (see WIRING.md)"
echo "============================================================"
