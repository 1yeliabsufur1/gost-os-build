#!/usr/bin/env bash
# ============================================================================
# GOST / PERIMETR — x86 live ISO builder (VirtualBox / any x86 PC)
# ----------------------------------------------------------------------------
# Builds gost-perimetr-live.iso: an Ubuntu Noble live system that boots
# straight into the head-unit kiosk. This is the VirtualBox test image; the
# Raspberry Pi uses tools/build-image.sh (ARM .img) instead.
#
#   sudo ./build-iso.sh          (on any Ubuntu/Debian x86_64 machine or WSL2)
#
# Output: gost-perimetr-live.iso (~400 MB)
# ============================================================================
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo."; exit 1; }

SRC="$(cd "$(dirname "$0")/.." && pwd)"
WORK="${WORK:-/tmp/gost-iso-build}"
OUT="${OUT:-$PWD/gost-perimetr-live.iso}"
MIRROR="${MIRROR:-http://archive.ubuntu.com/ubuntu}"

apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  debootstrap squashfs-tools xorriso grub-pc-bin grub-efi-amd64-bin grub-common mtools dosfstools

mkdir -p "$WORK" && cd "$WORK"

# ---- 1. base system ---------------------------------------------------------
[[ -d chroot ]] || debootstrap --variant=minbase --arch=amd64 noble chroot "$MIRROR"

cat > chroot/etc/apt/sources.list <<EOF
deb $MIRROR noble main universe
deb $MIRROR noble-updates main universe
deb http://security.ubuntu.com/ubuntu noble-security main universe
EOF
echo gost > chroot/etc/hostname

for m in proc sys dev dev/pts; do mountpoint -q chroot/$m || mount --bind /$m chroot/$m; done
trap 'for m in dev/pts dev sys proc; do umount -lf chroot/$m 2>/dev/null || true; done' EXIT

chroot chroot apt-get update -qq
DEBIAN_FRONTEND=noninteractive chroot chroot apt-get install -y -qq --no-install-recommends \
  linux-image-virtual casper systemd-sysv \
  network-manager wpasupplicant iw wireless-regdb ffmpeg \
  xserver-xorg-core xserver-xorg-video-vmware xserver-xorg-video-fbdev \
  xserver-xorg-input-libinput xinit x11-xserver-utils \
  openbox surf mpv alsa-utils \
  gstreamer1.0-plugins-good gstreamer1.0-libav gstreamer1.0-alsa \
  python3 python3-pip python3-serial fonts-dejavu-core ca-certificates

# CRITICAL: the virtual kernel ships without squashfs/overlay modules — casper
# cannot mount the live filesystem without them ("No such device" at boot).
KVER=$(basename chroot/boot/vmlinuz-* | sed 's/vmlinuz-//')
DEBIAN_FRONTEND=noninteractive chroot chroot apt-get install -y -qq --no-install-recommends \
  "linux-modules-extra-$KVER"
chroot chroot update-initramfs -u -k "$KVER"

# ---- 2. python deps (wheels fetched on host; chroot has no DNS) -------------
mkdir -p wheels && pip3 download -q -d wheels websockets obd
cp -r wheels chroot/wheels
chroot chroot pip3 install --break-system-packages -q --no-index --find-links=/wheels websockets obd
rm -rf chroot/wheels

# ---- 3. the app + kiosk autostart -------------------------------------------
mkdir -p chroot/opt/gost/media/Videos chroot/opt/gost/system
cp -r "$SRC/app" "$SRC/backend" "$SRC/tools" "$SRC/docs" chroot/opt/gost/

cat > chroot/opt/gost/system/iso-kiosk.sh <<'EOF'
#!/bin/bash
python3 /opt/gost/backend/hud_server.py &
openbox &
sleep 1
xset s off -dpms 2>/dev/null
exec surf -F file:///opt/gost/app/index.html
EOF
chmod +x chroot/opt/gost/system/iso-kiosk.sh

cat > chroot/etc/systemd/system/gost-kiosk.service <<'EOF'
[Unit]
Description=GOST/PERIMETR kiosk (live ISO)
After=systemd-user-sessions.service
Conflicts=getty@tty1.service

[Service]
ExecStart=/usr/bin/xinit /opt/gost/system/iso-kiosk.sh -- :0 vt1 -nolisten tcp
Restart=always
RestartSec=2

[Install]
WantedBy=graphical.target
EOF
mkdir -p chroot/etc/systemd/system/graphical.target.wants
ln -sf /etc/systemd/system/gost-kiosk.service chroot/etc/systemd/system/graphical.target.wants/gost-kiosk.service
ln -sf /lib/systemd/system/graphical.target chroot/etc/systemd/system/default.target

chroot chroot apt-get clean
rm -rf chroot/var/lib/apt/lists/* chroot/var/cache/* chroot/usr/share/doc/* chroot/usr/share/man/*

# ---- 4. squashfs + ISO --------------------------------------------------------
for m in dev/pts dev sys proc; do umount -lf chroot/$m 2>/dev/null || true; done
trap - EXIT
mkdir -p iso/casper iso/boot/grub
mksquashfs chroot iso/casper/filesystem.squashfs -comp zstd -Xcompression-level 12 -noappend -quiet
cp chroot/boot/vmlinuz-* iso/casper/vmlinuz
cp chroot/boot/initrd.img-* iso/casper/initrd
du -sx --block-size=1 chroot | cut -f1 > iso/casper/filesystem.size

cat > iso/boot/grub/grub.cfg <<'EOF'
set default=0
set timeout=3
menuentry "GOST / PERIMETR OS (Live)" {
    linux /casper/vmlinuz boot=casper quiet ---
    initrd /casper/initrd
}
menuentry "GOST / PERIMETR OS (safe graphics)" {
    linux /casper/vmlinuz boot=casper nomodeset quiet ---
    initrd /casper/initrd
}
EOF

grub-mkrescue -o "$OUT" iso --volid GOST_PERIMETR
echo; echo "Built: $OUT"
