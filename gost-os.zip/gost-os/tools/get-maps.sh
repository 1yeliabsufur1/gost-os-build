#!/usr/bin/env bash
# Downloads/updates the offline map region into maps/ (requires Wi-Fi).
# Set REGION_URL to your area's .pmtiles build. Free worldwide + regional
# extracts: https://protomaps.com/downloads  (or maps.protomaps.com builds).
# Example (whole planet basemap build, large):
#   REGION_URL="https://build.protomaps.com/$(date +%Y%m%d)".pmtiles   # daily build
REGION_URL="${REGION_URL:-}"
DEST="$(cd "$(dirname "$0")/.." && pwd)/maps/region.pmtiles"
if [[ -z "$REGION_URL" ]]; then
  echo "Set REGION_URL (see protomaps.com/downloads) at the top of this script"; exit 1
fi
mkdir -p "$(dirname "$DEST")"
echo "Fetching $REGION_URL -> $DEST"
wget -O "$DEST.part" "$REGION_URL" && mv "$DEST.part" "$DEST" && echo "Map updated."
