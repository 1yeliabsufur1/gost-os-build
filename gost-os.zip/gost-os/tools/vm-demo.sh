#!/usr/bin/env bash
# ============================================================================
# GOST / PERIMETR — VirtualBox / x86 demo
# ----------------------------------------------------------------------------
# The real OS image is ARM and cannot boot in VirtualBox. This script gives you
# the equivalent experience on x86: run it inside any stock Ubuntu VM (22.04+)
# and it turns that VM into the head unit — backend + fullscreen kiosk UI.
#
#   1) Install Ubuntu Desktop in VirtualBox, log in
#   2) Copy the gost-os folder into the VM
#   3) bash gost-os/tools/vm-demo.sh
#
# Controls: arrow keys = D-pad, Enter = select, T = theme, C = CRT.
# GPIO/pots/OBD don't exist in a VM, so the backend runs its simulator —
# exactly what it does on a bench Pi with nothing wired up yet.
# Add --autostart to make the VM boot into the kiosk on every login.
# ============================================================================
set -euo pipefail

SRC="$(cd "$(dirname "$0")/.." && pwd)"
AUTOSTART=false
[[ "${1:-}" == "--autostart" ]] && AUTOSTART=true

echo "==> Installing packages (sudo)…"
sudo apt-get update
sudo apt-get install -y --no-install-recommends chromium-browser mpv python3 python3-pip python3-venv \
  || sudo apt-get install -y --no-install-recommends chromium mpv python3 python3-pip python3-venv

echo "==> Python env…"
python3 -m venv "$HOME/.gost-venv"
"$HOME/.gost-venv/bin/pip" -q install --upgrade pip websockets obd

CHROME=$(command -v chromium-browser || command -v chromium)

LAUNCH="$HOME/.gost-launch.sh"
cat > "$LAUNCH" <<EOF
#!/usr/bin/env bash
"$HOME/.gost-venv/bin/python" "$SRC/backend/hud_server.py" &
BACK=\$!
sleep 1
"$CHROME" --kiosk --noerrdialogs --disable-infobars --hide-scrollbars \\
  --autoplay-policy=no-user-gesture-required "file://$SRC/app/index.html"
kill \$BACK 2>/dev/null
EOF
chmod +x "$LAUNCH"

if $AUTOSTART; then
  mkdir -p "$HOME/.config/autostart"
  cat > "$HOME/.config/autostart/gost-kiosk.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=GOST Kiosk
Exec=$LAUNCH
X-GNOME-Autostart-enabled=true
EOF
  echo "==> Autostart enabled — the VM now boots into the head unit on login."
fi

echo "==> Launching…"
exec "$LAUNCH"
