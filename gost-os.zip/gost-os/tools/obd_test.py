#!/usr/bin/env python3
"""
F-150 / OBD-II live read test
=============================
Plug a cheap ELM327 USB adapter into the vehicle's OBD-II port and your laptop
or the Pi. This connects, lists supported PIDs, and streams a few live values so
you can confirm the read pipeline works on a real, moving vehicle BEFORE trusting
it in the head unit.

    pip install obd
    python3 obd_test.py            # auto-detect port
    python3 obd_test.py /dev/ttyUSB0

Reminder: a gas F-150 does NOT expose EV PIDs (state of charge, kWh, regen).
This test proves "can I read a live vehicle and map values into gauges." On the
Slate, the same slots are filled by the BLE telematics feed instead.
"""
import sys, time

try:
    import obd
except ImportError:
    sys.exit("Install first:  pip install obd")

port = sys.argv[1] if len(sys.argv) > 1 else None
print("Connecting" + (f" on {port}" if port else " (auto-detect)…"))
conn = obd.OBD(port) if port else obd.OBD()

if not conn.is_connected():
    sys.exit("Not connected. Check the adapter, ignition on, and the port "
             "(Linux: /dev/ttyUSB0, look in `dmesg`; adapter may need pairing).")

print("Connected:", conn.status())
print("Protocol :", conn.protocol_name())
print(f"Supported commands: {len(conn.supported_commands)}\n")

# Values we map into the head-unit cluster during the F-150 test:
WATCH = [
    ("SPEED",        obd.commands.SPEED,        "-> speed gauge"),
    ("RPM",          obd.commands.RPM,          "(engine only)"),
    ("FUEL_LEVEL",   obd.commands.FUEL_LEVEL,   "-> SoC gauge (stand-in)"),
    ("COOLANT_TEMP", obd.commands.COOLANT_TEMP, "-> motor temp (stand-in)"),
    ("THROTTLE_POS", obd.commands.THROTTLE_POS, "-> power (stand-in)"),
]

print("Streaming (Ctrl-C to stop):\n")
try:
    while True:
        line = []
        for name, cmd, note in WATCH:
            if cmd in conn.supported_commands:
                r = conn.query(cmd)
                v = "n/a" if (r is None or r.value is None) else str(r.value)
            else:
                v = "unsupported"
            line.append(f"{name}={v}")
        print("  " + " | ".join(line))
        time.sleep(0.5)
except KeyboardInterrupt:
    print("\nStopped.")
finally:
    conn.close()
