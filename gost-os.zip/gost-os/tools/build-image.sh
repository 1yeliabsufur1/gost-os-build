#!/usr/bin/env bash
# ============================================================================
# GOST / PERIMETR  —  OS image builder
# ----------------------------------------------------------------------------
# Produces a flashable Raspberry Pi 5 image (gost-perimetr-os.img) from the
# official Raspberry Pi OS Lite (64-bit) base, with GOST/PERIMETR baked in.
# On first boot the image installs itself (needs network once), then every
# boot after that goes straight into the head-unit kiosk.
#
# Run on any Linux machine or WSL2 (Windows):
#     sudo ./build-image.sh
#
# Flash the result with Raspberry Pi Imager or balenaEtcher.
# NOTE: this is a .img (Pi standard), not a .iso — and it will NOT boot in
# VirtualBox (ARM vs x86). For VBox testing use app/index.html + hud_server.py.
# ============================================================================
set -euo pipefail

# ---- config ----------------------------------------------------------------
BASE_URL="${BASE_URL:-https://downloads.raspberrypi.com/raspios_lite_arm64_latest}"
WORK="${WORK:-./image-build}"
OUT="${OUT:-gost-perimetr-os.img}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"   # the gost-os folder

[[ $EUID -eq 0 ]] || { echo "Run with sudo (needs loop mounts)."; exit 1; }
for t in wget xz losetup mount rsync; do
  command -v "$t" >/dev/null || { echo "Missing tool: $t (apt install $t)"; exit 1; }
done

mkdir -p "$WORK"; cd "$WORK"

# ---- 1. fetch base image ----------------------------------------------------
if [[ ! -f base.img ]]; then
  echo "==> Downloading Raspberry Pi OS Lite (64-bit)…"
  wget -q --show-progress -O base.img.xz "$BASE_URL"
  echo "==> Decompressing…"
  xz -dv base.img.xz
  mv base.img* base.img 2>/dev/null || true
fi
cp --sparse=always base.img "$OUT"

# ---- 2. mount both partitions ----------------------------------------------
echo "==> Mounting image…"
LOOP=$(losetup -fP --show "$OUT")
trap 'umount -q boot root 2>/dev/null || true; losetup -d "$LOOP" 2>/dev/null || true' EXIT
# WSL2/slow-udev guard: wait for the partition device nodes to appear
for i in $(seq 1 20); do [[ -b "${LOOP}p1" && -b "${LOOP}p2" ]] && break; sleep 0.5; partprobe "$LOOP" 2>/dev/null || true; done
[[ -b "${LOOP}p1" ]] || { echo "Loop partitions never appeared. On WSL2: wsl --update, restart, retry."; exit 1; }
mkdir -p boot root
mount "${LOOP}p1" boot
mount "${LOOP}p2" root

# ---- 3. inject the project --------------------------------------------------
echo "==> Injecting GOST/PERIMETR…"
mkdir -p root/opt/gost-src
rsync -a --exclude image-build --exclude '*.img*' \
  "$SRC/app" "$SRC/backend" "$SRC/system" "$SRC/tools" "$SRC/docs" \
  "$SRC/install.sh" "$SRC/README.md" root/opt/gost-src/
[[ -d "$SRC/media" ]] && rsync -a "$SRC/media" root/opt/gost-src/
[[ -d "$SRC/maps"  ]] && rsync -a "$SRC/maps"  root/opt/gost-src/
mkdir -p root/opt/gost-src/media/TV root/opt/gost-src/media/Dashcam root/opt/gost-src/maps
chmod +x root/opt/gost-src/install.sh root/opt/gost-src/system/kiosk-start.sh

# enable SPI now (no waiting for first boot)
grep -q '^dtparam=spi=on' boot/config.txt || echo 'dtparam=spi=on' >> boot/config.txt
# DSI ribbon displays + ribbon camera: auto-detect (explicit; used by dashcam + touchscreens)
grep -q '^display_auto_detect=1' boot/config.txt || echo 'display_auto_detect=1' >> boot/config.txt
grep -q '^camera_auto_detect=1'  boot/config.txt || echo 'camera_auto_detect=1'  >> boot/config.txt

# ---- 4. first-boot self-install ----------------------------------------------
cat > root/etc/systemd/system/gost-firstboot.service <<'EOF'
[Unit]
Description=GOST/PERIMETR first-boot self-install
After=network-online.target
Wants=network-online.target
ConditionPathExists=!/opt/gost/.installed

[Service]
Type=oneshot
ExecStart=/bin/bash -c '/opt/gost-src/install.sh && touch /opt/gost/.installed && systemctl disable gost-firstboot && reboot'
TimeoutStartSec=0
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
ln -sf /etc/systemd/system/gost-firstboot.service \
  root/etc/systemd/system/multi-user.target.wants/gost-firstboot.service

# ---- 5. finish ----------------------------------------------------------------
sync
umount boot root; losetup -d "$LOOP"; trap - EXIT
mv "$OUT" "$SRC/"
echo
echo "============================================================"
echo " Built: $SRC/$OUT"
echo " Flash it with Raspberry Pi Imager, boot the Pi 5 with"
echo " network connected. First boot self-installs (a few minutes,"
echo " one auto-reboot), then it comes up as the head unit."
echo "============================================================"
