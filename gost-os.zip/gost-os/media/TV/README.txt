TV CHANNELS
===========
Each folder here is a channel. Name folders with the channel number first:

  03 Cartoons/
  07 Movies/
  45 Home Videos/

Numbers 3-82 (83 is the built-in YouTube channel). Drop .mp4 files inside (H.264 = smooth hardware decode on Pi 5).
Channels appear automatically. USB sticks work too: put a TV/ folder on the stick.
Channel 02 SCHEDULE plays whatever the TV Guide assigns to the current time slot.
