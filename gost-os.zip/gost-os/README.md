# GOST / PERIMETR — Slate Head-Unit OS

A custom, offline head-unit interface for a Raspberry Pi 5 that boots straight
into a hard-edged, Soviet-brutalist / cyberpunk telemetry dashboard. Built for
the Slate truck's bring-your-own-device dash — but it reads any vehicle.

Two selectable skins on one system: **GOST** (amber engineering-standard) and
**PERIMETR** (red doomsday alert). Switch in Settings or with `T`.

## What's in the box

```
gost-os/
  app/index.html          the whole UI (one file, runs standalone too)
  backend/hud_server.py   hardware + OBD + video + telemetry over a local websocket
  backend/requirements.txt
  system/                 systemd kiosk units + Chromium launch script
  tools/obd_test.py       F-150 / OBD-II live-read tester
  docs/WIRING.md          pinouts: 5 buttons + 2 pots (MCP3008)
  install.sh              one-command Pi setup
```

## Controls

Five-way D-pad + two knobs:

- **◀ ▶** — switch tabs (HOME · DRIVE · MEDIA · VIDEO · NAV · COMMS · SETTINGS)
- **▲ ▼** — move the cursor within a tab
- **●** Enter — select
- **VOL / BRT** knobs — volume and screen brightness (always live)

The tab strip you flick through with ◀▶ is the "windows-like" hub; HOME is the
launcher, SETTINGS holds theme / CRT / brightness / folders.

## Test it now (no hardware)

**Fastest:** open `app/index.html` in any browser — on your phone or in a
VirtualBox Linux guest. It self-simulates: arrow keys + Enter drive the D-pad,
the cluster animates, and the VIDEO tab's "Open a video file…" actually plays a
file you pick so you can judge playback and UX. This is the part you're rating
"up to snuff," and it ports 1:1 to the Pi.

**Full stack in VBox (optional):** an x86 Linux guest can also run the backend
to test the websocket + video scan + navigation end-to-end (GPIO/pots/OBD are
Pi-only and auto-fall back to sim):

```bash
pip install websockets obd
python3 backend/hud_server.py         # serves ws://localhost:8765
# then open app/index.html in Chromium on the same machine
```

The status bar flips from **STANDALONE** to **LINK OK / BACKEND** when connected.

> VirtualBox is x86 and can't emulate the Pi's ARM CPU, GPIO, SPI, or Bluetooth.
> Use it to validate software and UX only. The button/pot/OBD bring-up happens on
> the real Pi.

## Install on the Raspberry Pi 5

1. Flash **Raspberry Pi OS Lite (64-bit)** to the SD card, boot, connect network.
2. Copy this folder to the Pi and run:
   ```bash
   sudo ./install.sh
   sudo reboot
   ```
3. It boots into the head unit automatically (Chromium in a `cage` kiosk).
4. Drop `.mp4` files into `/opt/gost/media/Videos` or plug in a USB stick — the
   VIDEO tab picks them up.

Wiring for the buttons and pots is in `docs/WIRING.md`.

## Test with your F-150 first

Before the Slate exists to read, prove the pipeline on a real vehicle:

```bash
pip install obd
python3 tools/obd_test.py        # ELM327 USB in the OBD-II port, ignition on
```

Standard OBD-II has no EV PIDs, so the backend maps gas-vehicle values into the
same gauge slots for the test (speed→speed, fuel→SoC, coolant→motor temp). It
validates read→parse→render; the Slate later swaps the OBD source for its BLE
telematics feed and supplies real EV numbers into those same keys.

## Media / video notes

Stick to **H.264 MP4** — the Pi 5 hardware-decodes it smoothly. HEVC/MKV can drop
to software decode and stutter; AVI is unreliable. Heavy files hand off to `mpv`;
the in-browser player handles the rest.

## SD-card safety (do this before daily use)

Vehicle power gets cut hard. Run a **read-only root with a tmpfs overlay** and a
small writable partition for settings/logs, or the card will corrupt. Wire
ignition-sense to a GPIO (or an RP2040 supervisor) to trigger a graceful
shutdown. This is the single most important hardening step for a car install.

## Roadmap / stubs

- **NAV** is a styled placeholder — real build is MapLibre GL + offline PMTiles.
- **COMMS** shows the UI — wire to local Ollama (whisper.cpp/Vosk → small model →
  Piper), fully offline.
- **BLE telematics parser** for the Slate replaces `obd_loop()` — needs the
  module's GATT service/characteristic UUIDs (sniff with nRF Connect).
- Reverse-cam auto-switch, dashcam, Bluetooth audio sink, trip logbook.
```
