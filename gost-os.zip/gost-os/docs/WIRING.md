# WIRING — GOST / PERIMETR input board (Raspberry Pi 5)

5 momentary buttons (5-way D-pad) + 2 potentiometers. Buttons go straight to
GPIO; pots go through an MCP3008 ADC because **the Pi 5 has no analog inputs.**

Enable SPI once (the installer does this): add `dtparam=spi=on` to
`/boot/firmware/config.txt`, then reboot.

## Buttons — direct GPIO, active-low

Each button: one leg to the GPIO pin, the other leg to any GND rail. Internal
pull-ups are enabled in software (`Button(pin, pull_up=True)`), so no external
resistors are needed. `bounce_time=0.03` handles debounce in software; a 100 nF
cap across each switch is a nice-to-have, not required.

| Function | BCM GPIO | Physical pin |
|----------|----------|--------------|
| UP       | GPIO5    | 29           |
| DOWN     | GPIO6    | 31           |
| LEFT     | GPIO13   | 33           |
| RIGHT    | GPIO19   | 35           |
| ENTER    | GPIO26   | 37           |
| GND rail | —        | 30, 34, 39   |

All five buttons and their grounds sit on the lower-right block of the header,
so the PCB routes cleanly on one side.

## Potentiometers — 2× 10kΩ linear via MCP3008 (SPI0)

Wire each pot as a voltage divider: outer legs to **3V3** and **GND**, wiper to
an ADC channel. **Use 3V3, never 5V** — the MCP3008 reference is 3.3V and 5V
would over-range every reading.

MCP3008 → Pi:

| MCP3008 pin      | Pi signal | BCM   | Physical |
|------------------|-----------|-------|----------|
| VDD + VREF       | 3V3       | —     | 1        |
| AGND + DGND      | GND       | —     | 25       |
| CLK              | SCLK      | GPIO11| 23       |
| DOUT             | MISO      | GPIO9 | 21       |
| DIN              | MOSI      | GPIO10| 19       |
| CS/SHDN          | CE0       | GPIO8 | 24       |
| CH0  ← VOL wiper | —         | —     | —        |
| CH1  ← BRT wiper | —         | —     | —        |

Six ADC channels (CH2–CH7) stay free for future knobs, a light sensor for
auto-brightness, etc.

## Reverse / accessory sense (optional, recommended)

Feed the truck's reverse-light signal through a divider/opto into a spare GPIO to
trigger the backup-camera auto-switch. Feed ignition/accessory sense into another
so an RP2040 (or the Pi itself) can do a graceful shutdown when power is cut —
this is what protects the SD card. See the read-only-root note in the README.

## When you outgrow this

At ~8+ controls, move everything onto an **RP2040** (it has a built-in ADC for
pots and does button debounce in hardware) that reports to the Pi as one USB
device. For 5 buttons + 2 pots, direct-to-Pi as above is simpler — do it first.
