#!/bin/bash
# Chromium kiosk for the Pi build. Waits for the backend HTTP server, then launches.
APP="http://127.0.0.1:8766/index.html"
for i in $(seq 1 40); do (exec 3<>/dev/tcp/127.0.0.1/8766) 2>/dev/null && break; sleep 0.5; done
CHROME=$(command -v chromium-browser || command -v chromium)
exec "$CHROME" --kiosk --ozone-platform=wayland --enable-features=UseOzonePlatform \
  --noerrdialogs --disable-infobars --disable-session-crashed-bubble --hide-scrollbars \
  --autoplay-policy=no-user-gesture-required --check-for-update-interval=31536000 \
  --overscroll-history-navigation=0 --app="$APP"
