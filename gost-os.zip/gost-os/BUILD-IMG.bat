@echo off
setlocal
title GOST/PERIMETR - Pi 5 image builder
echo ==================================================
echo  GOST / PERIMETR - Raspberry Pi 5 image builder
echo.
echo  Downloads the official Pi OS base (~500 MB) and
echo  bakes GOST into it. About 10 minutes.
echo  LEAVE THIS WINDOW OPEN until it says DONE.
echo ==================================================
echo.
cd /d "%~dp0."
del /q gost-perimetr-os.img >nul 2>nul

rem ---------- 1. is Ubuntu actually usable? ----------
set WSLOK=
for /f "usebackq delims=" %%i in (`wsl.exe -d Ubuntu -u root -e echo OK 2^>nul`) do set WSLOK=%%i
if "%WSLOK%"=="OK" goto build

echo  Ubuntu for Windows is not installed yet.
echo  Installing it now (one time, a few minutes).
echo  If Windows shows a permission prompt, click YES.
echo.
wsl.exe --install -d Ubuntu --no-launch
echo.
echo  Checking again...
set WSLOK=
for /f "usebackq delims=" %%i in (`wsl.exe -d Ubuntu -u root -e echo OK 2^>nul`) do set WSLOK=%%i
if "%WSLOK%"=="OK" goto build

echo.
echo  Automatic install did not finish. Manual one-time fix:
echo    1. Open the Microsoft Store, search "Ubuntu", Install
echo    2. Open "Ubuntu" once from the Start menu, let it finish
echo       (if it asks for a username, type: gost, any password)
echo    3. Double-click this file again
echo.
pause
exit /b 1

:build
rem ---------- 2. translate this folder's path ----------
set HEREUNIX=
for /f "usebackq delims=" %%i in (`wsl.exe -d Ubuntu -u root -e wslpath -a "%~dp0." 2^>nul`) do set HEREUNIX=%%i
if not "%HEREUNIX:~0,1%"=="/" ( echo  Path translation failed. & pause & exit /b 1 )

echo  Building... progress scrolls below (long pauses are normal).
echo.
wsl.exe -d Ubuntu -u root -e bash -c "set -e; apt-get update -qq >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y -qq wget xz-utils rsync ca-certificates util-linux >/dev/null 2>&1; rm -rf /root/gost-build; mkdir -p /root/gost-build; cp -r '%HEREUNIX%'/. /root/gost-build/; cd /root/gost-build/tools; sed -i 's/\r$//' build-image.sh ../install.sh ../system/*.sh 2>/dev/null || true; chmod +x build-image.sh ../install.sh ../system/*.sh 2>/dev/null || true; ./build-image.sh; cp -f /root/gost-build/gost-perimetr-os.img '%HEREUNIX%'/"

rem ---------- 3. trust only the actual file ----------
if not exist "%~dp0gost-perimetr-os.img" (
  echo.
  echo  BUILD FAILED - the image file was not produced.
  echo  Screenshot this whole window and send it to Claude.
  echo.
  pause
  exit /b 1
)

echo.
echo ==================================================
echo  DONE!  gost-perimetr-os.img is in this folder.
echo.
echo  Raspberry Pi Imager:
echo    Device: Raspberry Pi 5
echo    OS: "Use custom" - pick gost-perimetr-os.img
echo    GEAR icon: enter your Wi-Fi name + password
echo    Write to SD card
echo.
echo  First Pi boot: a few minutes + one self-reboot,
echo  then it comes up as the head unit.
echo ==================================================
pause
