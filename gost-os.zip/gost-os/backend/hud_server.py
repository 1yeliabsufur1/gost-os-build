#!/usr/bin/env python3
"""
GOST / PERIMETR OS — backend v2
================================
Serves the UI over HTTP (with Range support, required for offline .pmtiles
maps), and bridges hardware/vehicle/network to it over a local websocket.

  HTTP : http://127.0.0.1:8766/   (app + /maps/)          [localhost only]
  WS   : ws://127.0.0.1:8765/                              [localhost only]

Data-source honesty: mode 'auto' reports source='none' until a real OBD
adapter (or future BLE telematics) is present — the UI shows NOT CONNECTED.
Mode 'demo' runs the simulator, and is labeled as such.

TV channels: folders under MEDIA/TV named like "07 Cartoons" become channel 7.
Playback is mpv fullscreen with a wall-clock offset = pseudo-broadcast.

Hardware map (docs/WIRING.md): buttons GPIO5/6/13/19/26, pots MCP3008 CH0/CH1.
LEFT button held 5 s = exit TV / kill launched apps (matches on-screen rule).
"""
import asyncio, json, os, glob, subprocess, signal, sys, time, threading, re
import http.server, socketserver
from functools import partial

try:
    import websockets
except ImportError:
    sys.exit("Missing dep: pip install websockets")

# ---------------- optional hardware ----------------
HAVE_GPIO = False
try:
    from gpiozero import Button, MCP3008
    HAVE_GPIO = True
except Exception:
    pass

HAVE_OBD = False
try:
    import obd
    HAVE_OBD = True
except Exception:
    pass

try:
    import serial  # for NMEA GPS
    HAVE_SERIAL = True
except Exception:
    HAVE_SERIAL = False

# ---------------- paths / config ----------------
ROOT      = "/opt/gost" if os.path.isdir("/opt/gost") else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR   = os.path.join(ROOT, "app")
MEDIA     = os.path.join(ROOT, "media")
TV_DIR    = os.path.join(MEDIA, "TV")
DASH_DIR  = os.path.join(MEDIA, "Dashcam")
MAPS_DIR  = os.path.join(ROOT, "maps")
STATE_F   = os.path.join(MEDIA, "state.json")
for d in (TV_DIR, DASH_DIR, MAPS_DIR):
    os.makedirs(d, exist_ok=True)

WS_PORT, HTTP_PORT = 8765, 8766
VIDEO_EXT = (".mp4", ".m4v", ".mov", ".mkv")
POLL_HZ = 5
BUTTONS = {"up": 5, "down": 6, "left": 13, "right": 19, "enter": 26}

clients = set()
loop = None
telemetry = {"speed": None, "soc": None, "pwr": None, "rpm": None,
             "mtemp": None, "ptemp": None, "fuel": None, "gear": None,
             "v12": None, "boost": None, "otemp": None, "mpg": None, "dtc": [], "source": "none"}
cfg = {"srcmode": "auto", "guide": {}}
procs = {"tv": None, "app": None, "dash": None}

def load_state():
    try:
        cfg.update(json.load(open(STATE_F)))
    except Exception:
        pass
def save_state():
    try:
        json.dump(cfg, open(STATE_F, "w"))
    except Exception:
        pass

# ---------------- broadcast ----------------
async def broadcast(msg):
    if not clients: return
    data = json.dumps(msg); dead = []
    for w in clients:
        try: await w.send(data)
        except Exception: dead.append(w)
    for w in dead: clients.discard(w)

def push(msg):
    if loop: asyncio.run_coroutine_threadsafe(broadcast(msg), loop)

# ---------------- HTTP: app + maps, with Range support ----------------
class RangeHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def send_head(self):
        path = self.translate_path(self.path)
        if os.path.isdir(path):
            self.path = self.path.rstrip("/") + "/index.html"
            path = self.translate_path(self.path)
        if not os.path.isfile(path):
            self.send_error(404); return None
        size = os.path.getsize(path)
        rng = self.headers.get("Range")
        f = open(path, "rb")
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            start = int(m.group(1) or 0)
            end = int(m.group(2)) if m.group(2) else size - 1
            end = min(end, size - 1)
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Type", self.guess_type(path))
            self.end_headers()
            f.seek(start); self._range = end - start + 1
            return f
        self.send_response(200)
        self.send_header("Content-Length", str(size))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Type", self.guess_type(path))
        self.end_headers()
        self._range = None
        return f
    def copyfile(self, src, dst):
        if getattr(self, "_range", None):
            dst.write(src.read(self._range))
        else:
            super().copyfile(src, dst)

def http_thread():
    os.makedirs(os.path.join(APP_DIR, "maps_link"), exist_ok=True)
    # serve APP_DIR; expose maps via symlink app/maps -> MAPS_DIR
    link = os.path.join(APP_DIR, "maps")
    if not os.path.islink(link):
        try:
            if os.path.exists(link): pass
            else: os.symlink(MAPS_DIR, link)
        except Exception: pass
    handler = partial(RangeHandler, directory=APP_DIR)
    with socketserver.ThreadingTCPServer(("127.0.0.1", HTTP_PORT), handler) as srv:
        srv.daemon_threads = True
        srv.serve_forever()

# ---------------- inputs ----------------
def setup_buttons():
    if not HAVE_GPIO: return
    try:
        _setup_buttons_inner()
    except Exception as e:
        print("[gost] buttons unavailable:", e)

def _setup_buttons_inner():
    def press(a):
        if a == "left": push({"type": "input", "action": "left_down"})
        else: push({"type": "input", "action": a})
    def release(a):
        if a == "left": push({"type": "input", "action": "left_up"})
    for action, pin in BUTTONS.items():
        b = Button(pin, pull_up=True, bounce_time=0.03)
        b.when_pressed  = (lambda a=action: press(a))
        b.when_released = (lambda a=action: release(a))
        setattr(_setup_buttons_inner, "_" + action, b)
    # physical LEFT hold 5s -> global back/kill (matches UI rule)
    lb = getattr(_setup_buttons_inner, "_left")
    lb.hold_time = 5.0
    lb.when_held = lambda: (kill_apps(), push({"type": "toast", "text": "BACK"}))

async def poll_pots():
    if not HAVE_GPIO: return
    try:
        vol, brt = MCP3008(channel=0), MCP3008(channel=1)
    except Exception as e:
        print("[gost] pots unavailable:", e); return
    last = {"vol": -9, "brt": -9}
    while True:
        for name, ch in (("vol", vol), ("brt", brt)):
            v = round(ch.value * 100)
            if abs(v - last[name]) >= 2:
                last[name] = v
                await broadcast({"type": "pot", "name": name, "value": v})
        await asyncio.sleep(0.08)

# ---------------- vehicle: auto (honest) / demo ----------------
async def vehicle_loop():
    conn = None
    while True:
        if cfg["srcmode"] == "demo":
            await demo_step()
        else:
            if conn is None and HAVE_OBD:
                conn = try_obd()
            if conn is not None:
                ok = read_obd(conn)
                if not ok:
                    try: conn.close()
                    except Exception: pass
                    conn = None
            if conn is None:
                if telemetry["source"] != "none":
                    for k in telemetry: telemetry[k] = None
                    telemetry["dtc"] = []
                telemetry["source"] = "none"
        await broadcast({"type": "telemetry", "data": telemetry})
        await asyncio.sleep(1 / POLL_HZ if telemetry["source"] != "none" else 2)

def try_obd():
    cands = sorted(glob.glob("/dev/ttyUSB*")) + sorted(glob.glob("/dev/ttyACM*")) + sorted(glob.glob("/dev/rfcomm*")) + [None]
    for p in cands:
        try:
            c = obd.OBD(p) if p else obd.OBD()
            if c.is_connected():
                telemetry["source"] = "obd"
                push({"type": "toast", "text": "OBD CONNECTED"})
                return c
            c.close()
        except Exception:
            pass
    return None

_slow = {"n": 0, "baro": None}
_dtc_seen = {}

def read_obd(conn):
    try:
        def q(cmd):
            r = conn.query(cmd)
            return None if (r is None or r.value is None) else r.value
        # --- fast tier: every tick (5 Hz) ---
        s = q(obd.commands.SPEED);        telemetry["speed"] = float(s.to("mile/hour").magnitude) if s is not None else telemetry["speed"]
        r = q(obd.commands.RPM);          telemetry["rpm"] = float(r.magnitude) if r is not None else None
        m = q(obd.commands.INTAKE_PRESSURE)
        if m is not None and _slow["baro"]:
            telemetry["boost"] = max(0.0, (float(m.magnitude) - _slow["baro"]) * 0.145038)
        maf = q(obd.commands.MAF)
        if maf is not None and telemetry["speed"] is not None:
            g = float(maf.to("gram/second").magnitude)
            telemetry["mpg"] = min(99.9, 11.3 * telemetry["speed"] / g) if g > 0.5 else None
        # --- slow tier: every ~2 s ---
        if _slow["n"] % 10 == 0:
            f = q(obd.commands.FUEL_LEVEL);   telemetry["fuel"] = float(f.magnitude) if f is not None else None
            c = q(obd.commands.COOLANT_TEMP); telemetry["mtemp"] = float(c.to("celsius").magnitude) if c is not None else None
            v = q(obd.commands.CONTROL_MODULE_VOLTAGE); telemetry["v12"] = float(v.magnitude) if v is not None else None
            o = q(obd.commands.OIL_TEMP);     telemetry["otemp"] = float(o.to("celsius").magnitude) if o is not None else None
            b = q(obd.commands.BAROMETRIC_PRESSURE)
            if b is not None: _slow["baro"] = float(b.magnitude)
            h = q(obd.commands.HYBRID_BATTERY_REMAINING)
            hs = float(h.magnitude) if h is not None else None
            telemetry["soc"] = hs if hs is not None else telemetry["fuel"]
        # --- DTC sweep: every ~30 s ---
        if _slow["n"] % 150 == 0:
            try:
                d = conn.query(obd.commands.GET_DTC)
                codes = d.value if (d is not None and d.value) else []
                now = time.strftime("%m-%d %H:%M")
                telemetry["dtc"] = [{"code": cd, "desc": (ds or "")[:44],
                                     "since": _dtc_seen.setdefault(cd, now)} for cd, ds in codes]
            except Exception:
                pass
        _slow["n"] += 1
        telemetry["gear"] = "D" if (telemetry["speed"] or 0) > 0.5 else "P"
        telemetry["source"] = "obd"
        return True
    except Exception:
        return False

_demo = {"ph": 0, "t": 3.0, "sp": 0.0, "soc": 72.0}
async def demo_step():
    d = _demo; d["t"] -= 1 / POLL_HZ
    if d["t"] <= 0:
        d["ph"] = (d["ph"] + 1) % 4; d["t"] = [4, 7, 3, 2][d["ph"]]
    tgt = [42, 58, 8, 0][d["ph"]]
    d["sp"] += (tgt - d["sp"]) * 0.15
    p = (tgt - d["sp"]) * 3 + d["sp"] * 0.9
    if d["ph"] == 2: p = -40
    p = max(-60, min(150, p))
    d["soc"] = max(0, d["soc"] - p / 3600 * 0.09)
    sag = (int(time.time()) % 22) < 3
    telemetry.update({"speed": d["sp"], "soc": d["soc"], "fuel": d["soc"], "pwr": p, "rpm": None,
                      "mtemp": 35 + abs(p) / 6, "ptemp": 27 + abs(p) / 12,
                      "v12": 11.8 if sag else 12.5, "boost": max(0.0, p / 11.0),
                      "otemp": 30 + abs(p) / 8,
                      "mpg": None if d["sp"] < 2 else max(6.0, 34 - p / 8),
                      "dtc": [{"code": "P1A42", "desc": "PROPULSION SYS STATUS PERF", "since": "06-29 07:14"}],
                      "gear": "D" if d["sp"] > 0.5 else "P", "source": "demo"})

# ---------------- TV channels ----------------
_durcache = {}
def probe_dur_min(path):
    """duration in minutes via ffprobe, cached by (path, mtime)"""
    try:
        key = (path, os.path.getmtime(path))
    except OSError:
        return 30
    if key in _durcache: return _durcache[key]
    dur = 30
    try:
        r = subprocess.run(["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
                            "-of", "csv=p=0", path], capture_output=True, text=True, timeout=20)
        dur = max(1, round(float(r.stdout.strip()) / 60))
    except Exception:
        pass
    _durcache[key] = dur
    return dur

def scan_channels():
    out = []
    for d in sorted(glob.glob(os.path.join(TV_DIR, "*"))) + sorted(glob.glob("/media/*/TV/*")):
        if not os.path.isdir(d): continue
        base = os.path.basename(d)
        m = re.match(r"^(\d{1,2})[\s_-]*(.*)$", base)
        if not m: continue
        num = int(m.group(1))
        if not (3 <= num <= 82): continue        # 83 is YouTube
        files = [f for f in sorted(glob.glob(os.path.join(d, "*"))) if f.lower().endswith(VIDEO_EXT)]
        if files:
            out.append({"num": num, "name": (m.group(2) or base).upper() or f"CH {num}",
                        "count": len(files), "_files": files,
                        "files": [{"n": os.path.basename(f), "d": probe_dur_min(f)} for f in files]})
    return out

_channels = []
async def channel_watch():
    global _channels
    last = None
    while True:
        chans = scan_channels()
        sig = tuple((c["num"], c["count"]) for c in chans)
        if sig != last:
            last = sig; _channels = chans
            await broadcast({"type": "channels", "list": [{k: c[k] for k in ("num", "name", "count", "files")} for c in chans]})
        await asyncio.sleep(4)

DAYK = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]
tv_current = {"num": None}

def now_block(num):
    """scheduled block containing wall-clock now -> (filepath, offset_sec) | None"""
    lt = time.localtime()
    day = DAYK[(lt.tm_wday + 1) % 7]           # tm_wday: Mon=0 -> our sun-first key
    g = (cfg.get("guide3") or {}).get(str(num)) or (cfg.get("guide3") or {}).get(num) or {}
    blocks = sorted(g.get(day) or [], key=lambda b: b.get("s", 0))
    now_s = lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec
    ch = next((c for c in _channels if c["num"] == num), None)
    for b in blocks:
        s, e = b.get("s", 0) * 60, (b.get("s", 0) + b.get("d", 0)) * 60
        if s <= now_s < e and ch:
            for f in ch["_files"]:
                if os.path.basename(f) == b.get("f"):
                    return f, now_s - s
    return None

def tv_play(num):
    tv_stop()
    tv_current["num"] = num
    if num == 83:                                   # YouTube-as-a-channel
        launch("youtube"); return
    ch = next((c for c in _channels if c["num"] == num), None)
    blk = now_block(num)
    if blk:
        f, off = blk
        procs["tv"] = subprocess.Popen(
            ["mpv", "--fullscreen", "--really-quiet", "--no-osc",
             f"--start=+{off}", "--input-conf=/dev/null", f],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    if ch and ch["_files"]:                         # unscheduled: continuous rotation, join mid-stream
        files = ch["_files"]
        durs = [probe_dur_min(f) * 60 for f in files]
        total = max(1, sum(durs))
        t = int(time.time()) % total
        idx = 0
        while t >= durs[idx]:
            t -= durs[idx]; idx = (idx + 1) % len(files)
        playlist = files[idx:] + files[:idx]
        procs["tv"] = subprocess.Popen(
            ["mpv", "--fullscreen", "--really-quiet", "--no-osc", "--loop-playlist=inf",
             f"--start=+{t}", "--input-conf=/dev/null"] + playlist,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return
    push({"type": "tv_offair", "num": num})         # UI shows static

async def tv_supervisor():
    """when a scheduled block's mpv ends, re-resolve the channel (next block or static)"""
    while True:
        p, num = procs["tv"], tv_current["num"]
        if num is not None and p is not None and p.poll() is not None:
            procs["tv"] = None
            tv_play(num)
        await asyncio.sleep(2)

def tv_stop():
    tv_current["num"] = None
    p = procs["tv"]
    if p and p.poll() is None: p.terminate()
    procs["tv"] = None

def tv_pause():
    # without IPC keep it simple: SIGSTOP/SIGCONT toggle
    p = procs["tv"]
    if not p or p.poll() is not None: return
    st = getattr(tv_pause, "_stopped", False)
    p.send_signal(signal.SIGCONT if st else signal.SIGSTOP)
    tv_pause._stopped = not st

# ---------------- launched apps (youtube / browser) ----------------
def browser_cmd(url):
    for b in ("chromium-browser", "chromium", "surf"):
        p = subprocess.run(["which", b], capture_output=True, text=True).stdout.strip()
        if p:
            if "surf" in b: return [p, "-F", url]
            return [p, "--kiosk", "--noerrdialogs", url]
    return None

def launch(app):
    kill_apps()
    url = "https://www.youtube.com/tv" if app == "youtube" else "https://duckduckgo.com"
    cmd = browser_cmd(url)
    if not cmd:
        push({"type": "toast", "text": "NO BROWSER AVAILABLE"}); return
    procs["app"] = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def kill_apps():
    tv_stop()
    p = procs["app"]
    if p and p.poll() is None: p.terminate()
    procs["app"] = None

# ---------------- dashcam (Pi camera ribbon) ----------------
def dashcam_available():
    return bool(subprocess.run(["which", "rpicam-vid"], capture_output=True).stdout.strip())

def dashcam_toggle():
    p = procs["dash"]
    if p and p.poll() is None:
        p.terminate(); procs["dash"] = None
        push({"type": "dashcam", "status": "OFF"}); return
    if not dashcam_available():
        push({"type": "dashcam", "status": "NO CAMERA"}); return
    out = os.path.join(DASH_DIR, "dash_%Y%m%d_%H%M%S.h264")
    procs["dash"] = subprocess.Popen(
        ["rpicam-vid", "-t", "0", "--segment", "300000", "--width", "1280", "--height", "720",
         "--framerate", "30", "-o", out, "-n"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    push({"type": "dashcam", "status": "RECORDING"})

async def dash_prune():
    while True:
        try:
            files = sorted(glob.glob(os.path.join(DASH_DIR, "dash_*")), key=os.path.getmtime)
            st = os.statvfs(DASH_DIR)
            while files and st.f_bavail * st.f_frsize < 2 * 1024**3:   # keep 2 GB free
                os.remove(files.pop(0)); st = os.statvfs(DASH_DIR)
        except Exception:
            pass
        await asyncio.sleep(60)

# ---------------- wifi (NetworkManager) ----------------
def nmcli(*args):
    try:
        return subprocess.run(["nmcli", *args], capture_output=True, text=True, timeout=25).stdout
    except Exception:
        return ""

def net_info():
    out = nmcli("-t", "-f", "NAME,DEVICE,TYPE", "connection", "show", "--active")
    for line in out.splitlines():
        parts = (line.split(":") + ["", ""])[:3]
        name, dev, typ = parts
        if dev.startswith("wl"): return name, "wifi"
        if typ == "ethernet" or dev.startswith(("en", "eth")): return name, "eth"
    return None, None

def wifi_radio_present():
    return any(l.split(":")[1:2] == ["wifi"] for l in nmcli("-t", "-f", "DEVICE,TYPE", "device").splitlines())

def wifi_status():
    return net_info()[0]

def wifi_scan():
    out = nmcli("-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "yes")
    nets, seen = [], set()
    for line in out.splitlines():
        parts = line.split(":")
        if len(parts) < 3 or not parts[0] or parts[0] in seen: continue
        seen.add(parts[0])
        nets.append({"ssid": parts[0], "sig": int(parts[1] or 0), "sec": parts[2]})
    return sorted(nets, key=lambda n: -n["sig"])[:15]

def wifi_connect(ssid, psk):
    if psk:
        r = subprocess.run(["nmcli", "dev", "wifi", "connect", ssid, "password", psk],
                           capture_output=True, text=True)
    else:
        r = subprocess.run(["nmcli", "dev", "wifi", "connect", ssid], capture_output=True, text=True)
    ok = r.returncode == 0
    push({"type": "toast", "text": ("CONNECTED " + ssid) if ok else "WI-FI CONNECT FAILED"})
    push({"type": "net", "status": wifi_status() or "—"})

async def net_watch():
    last = None
    while True:
        name, kind = net_info()
        cur = (name or "—", kind or "-")
        if cur != last:
            last = cur
            await broadcast({"type": "net", "status": cur[0], "kind": cur[1]})
        await asyncio.sleep(8)

# ---------------- updates ----------------
def system_update():
    def run():
        push({"type": "toast", "text": "UPDATING SYSTEM…"})
        r = subprocess.run(["bash", "-c",
             "apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get upgrade -y -qq"],
            capture_output=True, text=True)
        push({"type": "toast", "text": "SYSTEM UPDATE " + ("DONE" if r.returncode == 0 else "FAILED (needs Wi-Fi/root)")})
    threading.Thread(target=run, daemon=True).start()

def update_maps():
    def run():
        script = os.path.join(ROOT, "tools", "get-maps.sh")
        if not os.path.isfile(script):
            push({"type": "toast", "text": "get-maps.sh missing"}); return
        r = subprocess.run(["bash", script], capture_output=True, text=True)
        push({"type": "toast", "text": "MAP UPDATE " + ("DONE" if r.returncode == 0 else "FAILED (set region URL in tools/get-maps.sh)")})
        push_maps()
    threading.Thread(target=run, daemon=True).start()

def push_maps():
    files = sorted(glob.glob(os.path.join(MAPS_DIR, "*.pmtiles"))) + sorted(glob.glob("/media/*/*.pmtiles"))
    push({"type": "maps", "list": [{"name": os.path.basename(f),
          "url": f"http://127.0.0.1:{HTTP_PORT}/maps/{os.path.basename(f)}"} for f in files
          if f.startswith(MAPS_DIR)]})

# ---------------- GPS: NMEA over USB serial ----------------
def gps_thread():
    if not HAVE_SERIAL: return
    while True:
        port = None
        for p in sorted(glob.glob("/dev/ttyACM*")) + sorted(glob.glob("/dev/ttyUSB*")):
            try:
                s = serial.Serial(p, 9600, timeout=1.5)
                probe = s.read(200)
                if b"$G" in probe: port = s; break
                s.close()
            except Exception:
                pass
        if not port:
            time.sleep(10); continue
        try:
            while True:
                line = port.readline().decode(errors="ignore").strip()
                if line.startswith(("$GPRMC", "$GNRMC")):
                    f = line.split(",")
                    if len(f) > 7 and f[2] == "A":
                        lat = _dm(f[3], f[4]); lon = _dm(f[5], f[6])
                        spd = float(f[7] or 0) * 1.15078
                        push({"type": "gps", "fix": True, "lat": lat, "lon": lon, "speed": spd, "sats": _dm.sats})
                elif line.startswith(("$GPGGA", "$GNGGA")):
                    f = line.split(",")
                    if len(f) > 7:
                        try: _dm.sats = int(f[7] or 0)
                        except Exception: pass
        except Exception:
            try: port.close()
            except Exception: pass
            time.sleep(5)

def _dm(v, hemi):
    if not v: return None
    deg = int(float(v) / 100); mins = float(v) - deg * 100
    d = deg + mins / 60
    return -d if hemi in ("S", "W") else d
_dm.sats = 0

# ---------------- websocket ----------------
async def handler(ws):
    clients.add(ws)
    await ws.send(json.dumps({"type": "hello", "hw": HAVE_GPIO, "host": os.uname().machine}))
    await ws.send(json.dumps({"type": "channels",
        "list": [{k: c[k] for k in ("num", "name", "count", "files")} for c in _channels]}))
    _n, _k = net_info(); await ws.send(json.dumps({"type": "net", "status": _n or "—", "kind": _k or "-"}))
    push_maps()
    try:
        async for raw in ws:
            try: m = json.loads(raw)
            except Exception: continue
            t = m.get("type")
            if   t == "tv_play":       tv_play(int(m.get("num", 0)))
            elif t == "tv_stop":       tv_stop()
            elif t == "tv_pause":      tv_pause()
            elif t == "launch":        launch(m.get("app", "browser"))
            elif t == "kill_apps":     kill_apps()
            elif t == "dashcam_toggle": dashcam_toggle()
            elif t == "wifi_scan":     await broadcast({"type": "wifi_list", "nets": wifi_scan(), "radio": wifi_radio_present()})
            elif t == "wifi_connect":  threading.Thread(target=wifi_connect,
                                        args=(m.get("ssid", ""), m.get("psk", "")), daemon=True).start()
            elif t == "system_update": system_update()
            elif t == "update_maps":   update_maps()
            elif t == "set":
                cfg[m.get("key")] = m.get("value"); save_state()
    finally:
        clients.discard(ws)

# ---------------- main ----------------
async def main():
    global loop
    loop = asyncio.get_running_loop()
    load_state()
    setup_buttons()
    threading.Thread(target=http_thread, daemon=True).start()
    threading.Thread(target=gps_thread, daemon=True).start()
    async with websockets.serve(handler, "127.0.0.1", WS_PORT):
        print(f"[gost] ws:{WS_PORT} http:{HTTP_PORT} gpio={HAVE_GPIO} obd={HAVE_OBD}")
        await asyncio.gather(vehicle_loop(), poll_pots(), channel_watch(), net_watch(), dash_prune(), tv_supervisor())

if __name__ == "__main__":
    for s in (signal.SIGINT, signal.SIGTERM):
        signal.signal(s, lambda *_: (kill_apps(), sys.exit(0)))
    asyncio.run(main())
