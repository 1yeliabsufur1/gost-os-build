OFFLINE MAPS
============
Drop a .pmtiles region file here (or on a USB stick root) and NAV renders it
fully offline. Free extracts: https://protomaps.com/downloads
With Wi-Fi: SETTINGS -> UPDATE MAPS runs tools/get-maps.sh (set your region URL there once).
